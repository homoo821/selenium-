pytest-3.2.5
=======================================

pytest 3.2.5 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at http://doc.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Bruno Oliveira


Happy testing,
The pytest Development Team
