# -*- coding:utf-8 -*-
#Author: homoo
#Data: 2020/2/27
#File: logs.py

import logging

class MyLog():
    def my_log(self):
        my_logger = logging.getLogger()

        fh = logging.FileHandler('test.log',encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s->%(filename)s的日志信息：->%(message)s')
        fh.setFormatter(formatter)
        my_logger.setLevel('INFO')
        my_logger.addHandler(fh)
        my_logger.info('asfe')

        my_logger.removeHandler(fh)

if __name__ == '__main__':
    MyLog().my_log()