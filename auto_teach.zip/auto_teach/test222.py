# -*- coding:utf-8 -*-
#Author: homoo
#Data: 2020/6/5
#File: test222.py

from test import TestData

c = getattr(TestData,"Cookie")
print(c)
c=setattr(TestData,"Cookie","svwoemsaf")
print(getattr(TestData,"Cookie"))