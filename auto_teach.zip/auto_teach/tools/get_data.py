# -*- coding:utf-8 -*-
#Author: homoo
#Data: 2020/2/28
#File: get_data.py

class GetData():

    Cookie=None