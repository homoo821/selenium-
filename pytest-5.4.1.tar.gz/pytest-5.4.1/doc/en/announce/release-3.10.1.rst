pytest-3.10.1
=======================================

pytest 3.10.1 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest

The full changelog is available at https://docs.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Anthony Sottile
* Boris Feld
* Bruno Oliveira
* Daniel Hahler
* Fabien ZARIFIAN
* Jon Dufresne
* Ronny Pfannschmidt


Happy testing,
The pytest Development Team
