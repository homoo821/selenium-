# -*- coding:utf-8 -*-
#Author: homoo
#Data: 2020/6/7
#File: test_data_pandas.py

import pandas as pd

class ReadExcel():

    def read_excel(self):
        df = pd.read_excel("../data/test_data.xlsx")
        # data = df.loc[:].values
        # print(data)
        test_data = []
        for i in df.index.values:  # 获取行号的索引，并对其进行遍历：
            # 根据i来获取每一行指定的数据 并利用to_dict转成字典
            row_data = df.loc[i].to_dict()
            test_data.append(row_data)
        print("最终获取到的数据是：{0}".format(test_data))

if __name__ == '__main__':
    ReadExcel().read_excel()